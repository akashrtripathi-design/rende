'use strict';

const { fabric } = require('fabric');

/**
 * Instantiates Fabric.js objects from a layers array and adds them
 * to the canvas in z-index order.
 *
 * @param {fabric.StaticCanvas} canvas
 * @param {Array}               layers   - template.layers
 * @param {Object}              assetMap - { [id]: Buffer }
 */
async function hydrateLayers(canvas, layers, assetMap = {}) {
  const pending = [];

  for (const layer of layers) {
    if (layer.visible === false) continue;

    const props = { ...layer.properties };
    const zIndex = layer.zIndex || 0;

    switch (layer.type) {
      case 'rect':
        pending.push({ zIndex, obj: new fabric.Rect(props) });
        break;

      case 'circle':
        pending.push({ zIndex, obj: new fabric.Circle(props) });
        break;

      case 'text':
        pending.push({ zIndex, obj: new fabric.Text(props.text || '', props) });
        break;

      case 'itext':
        pending.push({ zIndex, obj: new fabric.IText(props.text || '', props) });
        break;

      case 'path':
        if (props.path) {
          pending.push({ zIndex, obj: new fabric.Path(props.path, props) });
        }
        break;

      case 'image': {
        const buf = props.srcId ? assetMap[props.srcId] : null;
        if (buf) {
          const b64 = `data:image/png;base64,${buf.toString('base64')}`;
          const img = await loadFabricImage(b64, props);
          pending.push({ zIndex, obj: img });
        } else {
          console.warn(`[hydration] Image asset not found for layer "${layer.id}"`);
        }
        break;
      }

      default:
        console.warn(`[hydration] Unsupported layer type: "${layer.type}"`);
    }
  }

  // Sort back-to-front by z-index, then add to canvas
  pending.sort((a, b) => a.zIndex - b.zIndex);
  for (const { obj } of pending) {
    canvas.add(obj);
  }

  canvas.renderAll();
}

/**
 * Wraps fabric.Image.fromURL in a Promise.
 */
function loadFabricImage(src, props) {
  return new Promise((resolve, reject) => {
    fabric.Image.fromURL(
      src,
      (img, err) => {
        if (err) return reject(new Error('fabric.Image.fromURL failed'));
        img.set(props);
        resolve(img);
      },
      { crossOrigin: 'anonymous' }
    );
  });
}

module.exports = { hydrateLayers };
