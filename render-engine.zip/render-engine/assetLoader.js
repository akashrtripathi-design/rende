'use strict';

const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { FontLibrary } = require('skia-canvas');

/**
 * Loads all assets (fonts + images) referenced in a template.
 * Returns a map of { [assetId]: Buffer }.
 */
async function loadAssets(template) {
  const assetMap = {};

  // ── Fonts ──────────────────────────────────────────────────────────────────
  if (template.assets && Array.isArray(template.assets.fonts)) {
    for (const font of template.assets.fonts) {
      if (font.path && fs.existsSync(path.resolve(font.path))) {
        try {
          FontLibrary.use(font.family, [path.resolve(font.path)]);
        } catch (e) {
          console.warn(`[assetLoader] Could not register font "${font.family}":`, e.message);
        }
      } else {
        console.warn(`[assetLoader] Font file not found: ${font.path}`);
      }
    }
  }

  // ── Images ─────────────────────────────────────────────────────────────────
  if (template.assets && Array.isArray(template.assets.images)) {
    await Promise.all(
      template.assets.images.map(async (img) => {
        try {
          if (img.url) {
            assetMap[img.id] = await fetchBuffer(img.url);
          } else if (img.path) {
            assetMap[img.id] = fs.readFileSync(path.resolve(img.path));
          }
        } catch (err) {
          console.error(`[assetLoader] Failed to load image "${img.id}":`, err.message);
        }
      })
    );
  }

  return assetMap;
}

/**
 * Fetches a URL and returns its body as a Buffer.
 * Uses Node's built-in http/https — no axios dependency needed.
 */
function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    client
      .get(url, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks)));
        res.on('error', reject);
      })
      .on('error', reject);
  });
}

module.exports = { loadAssets };
