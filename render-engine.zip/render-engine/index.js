'use strict';

// ─── Node.js / Skia-Canvas browser shim (must run before fabric loads) ───────
const skia = require('skia-canvas');

class MockDocument {}
global.Document = MockDocument;
global.HTMLDocument = MockDocument;

global.document = {
  documentElement: { style: {} },
  createElement(tag) {
    if (tag === 'canvas') {
      const canvas = new skia.Canvas(800, 600);
      const orig = canvas.getContext.bind(canvas);
      canvas.getContext = function (type, opts) {
        const ctx = orig(type, opts);
        if (ctx) {
          Object.defineProperty(ctx, 'canvas', {
            value: canvas,
            writable: true,
            configurable: true,
          });
        }
        return ctx;
      };
      canvas.style = {};
      canvas.classList = { add: () => {}, remove: () => {} };
      canvas.setAttribute = () => {};
      canvas.removeAttribute = () => {};
      canvas.getAttribute = () => null;
      return canvas;
    }
    return { style: {} };
  },
  getElementById: () => null,
};
Object.setPrototypeOf(global.document, MockDocument.prototype);

global.window = {
  document: global.document,
  devicePixelRatio: 1,
  setTimeout,
  clearTimeout,
  Image: skia.Image,
  location: { href: 'http://localhost' },
};
// ─────────────────────────────────────────────────────────────────────────────

const express = require('express');
const { fabric } = require('fabric');
const { loadAssets } = require('./assetLoader');
const { hydrateLayers } = require('./hydration');

fabric.document = global.document;
fabric.window = global.window;
fabric.isLikelyNode = true;

const app = express();
app.use(express.json({ limit: '10mb' }));

// ── GET / ────────────────────────────────────────────────────────────────────
app.get('/', (_req, res) => {
  res.send('Render Engine Running');
});

// ── POST /render ─────────────────────────────────────────────────────────────
app.post('/render', async (req, res) => {
  try {
    const template = req.body;

    if (!template || !template.canvas || !template.layers) {
      return res.status(400).json({
        error: 'Invalid template: missing required fields "canvas" or "layers".',
      });
    }

    const width = template.canvas.width || 800;
    const height = template.canvas.height || 600;
    const bgColor = template.canvas.backgroundColor || '#FFFFFF';
    const quality = template.canvas.quality || 0.9;

    // Load remote/local image assets
    const assetMap = await loadAssets(template);

    // Create Fabric static canvas backed by skia-canvas
    const canvas = new fabric.StaticCanvas(null, {
      width,
      height,
      backgroundColor: bgColor,
    });

    await hydrateLayers(canvas, template.layers, assetMap);

    const skiaCanvas = canvas.lowerCanvasEl;
    if (!skiaCanvas || typeof skiaCanvas.toBuffer !== 'function') {
      throw new Error('skia-canvas injection failed — lowerCanvasEl.toBuffer unavailable.');
    }

    const buffer = await skiaCanvas.toBuffer('png', { quality });

    res.set('Content-Type', 'image/png');
    res.send(buffer);
  } catch (err) {
    console.error('[render error]', err);
    res.status(500).json({ error: err.message || 'Render failed.' });
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Render Engine running on port ${PORT}`);
});
